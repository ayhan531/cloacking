# 🔥 Firebase Kurulum Rehberi

## 1. Firebase Projesi Oluşturma

1. [Firebase Console](https://console.firebase.google.com/) adresine gidin
2. "Add Project" (Proje Ekle) butonuna tıklayın
3. Proje adı girin (örn: "cloaking-platform")
4. Google Analytics'i istediğiniz gibi yapılandırın
5. "Create Project" butonuna tıklayın

## 2. Web App Ekleme

1. Firebase Console'da projenize tıklayın
2. "Web" ikonuna (</>)  tıklayın
3. App nickname girin (örn: "Cloaking Web")
4. "Register app" butonuna tıklayın
5. Firebase SDK configuration bilgilerini kopyalayın

## 3. Authentication Kurulumu

1. Sol menüden "Authentication" seçin
2. "Get Started" butonuna tıklayın
3. "Sign-in method" sekmesine gidin
4. "Email/Password" seçeneğini etkinleştirin
5. "Save" butonuna tıklayın

## 4. Firestore Database Kurulumu

1. Sol menüden "Firestore Database" seçin
2. "Create database" butonuna tıklayın
3. "Start in production mode" seçin
4. Location seçin (örn: europe-west1)
5. "Enable" butonuna tıklayın

## 5. Security Rules Ayarlama

Firestore Database'de "Rules" sekmesine gidin ve aşağıdaki kuralları yapıştırın:

\`\`\`javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Sites collection - herkes okuyabilir, sadece admin yazabilir
    match /sites/{siteId} {
      allow read: if true;
      allow write: if request.auth != null && 
                     exists(/databases/$(database)/documents/admins/$(request.auth.uid));
    }
    
    // Admins collection - sadece admin okuyabilir
    match /admins/{adminId} {
      allow read: if request.auth != null && request.auth.uid == adminId;
      allow write: if false;
    }
  }
}
\`\`\`

"Publish" butonuna tıklayın.

## 6. Environment Variables Ayarlama

1. Proje klasöründe `.env.local` dosyası oluşturun
2. Firebase SDK configuration bilgilerinizi ekleyin:

\`\`\`env
NEXT_PUBLIC_FIREBASE_API_KEY=AIza...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc...
\`\`\`

## 7. İlk Admin Kullanıcısı Oluşturma

### Adım 1: Authentication'da Kullanıcı Oluştur

1. Firebase Console → Authentication → Users
2. "Add user" butonuna tıklayın
3. Email ve şifre girin (örn: admin@example.com)
4. "Add user" butonuna tıklayın
5. **Oluşturulan kullanıcının UID'sini kopyalayın** (örn: `abc123def456...`)

### Adım 2: Firestore'da Admin Kaydı Oluştur

1. Firebase Console → Firestore Database
2. "Start collection" butonuna tıklayın
3. Collection ID: `admins`
4. "Next" butonuna tıklayın
5. Document ID: **Kopyaladığınız UID'yi yapıştırın**
6. Field ekleyin:
   - Field: `email` (type: string) → Value: `admin@example.com`
   - Field: `role` (type: string) → Value: `admin`
   - Field: `createdAt` (type: timestamp) → Value: (şu anki zaman)
7. "Save" butonuna tıklayın

## 8. Dev Server'ı Yeniden Başlatın

\`\`\`bash
# Ctrl+C ile mevcut server'ı durdurun
# Sonra tekrar başlatın:
npm run dev
\`\`\`

## 9. Admin Paneline Giriş Yapın

1. Tarayıcıda `http://localhost:3000/admin/login` adresine gidin
2. Oluşturduğunuz admin email ve şifre ile giriş yapın
3. Dashboard'a yönlendirileceksiniz

## ✅ Kurulum Tamamlandı!

Artık admin panelinden yeni siteler oluşturabilirsiniz.

## 🚨 Sorun Giderme

### "Firebase: Error (auth/invalid-api-key)"
- `.env.local` dosyasının doğru konumda olduğundan emin olun
- API key'in doğru kopyalandığından emin olun
- Dev server'ı yeniden başlatın

### "Giriş başarısız"
- Email ve şifrenin doğru olduğundan emin olun
- Authentication'da kullanıcının oluşturulduğundan emin olun

### "Admin paneline erişilemiyor"
- Firestore'da `admins` collection'ında kullanıcınızın kaydının olduğundan emin olun
- UID'nin doğru olduğundan emin olun

### "Site oluşturulamıyor"
- Firestore Security Rules'un doğru ayarlandığından emin olun
- Admin kullanıcısının `admins` collection'ında olduğundan emin olun
