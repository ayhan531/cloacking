'use client';

import { useEffect, useState } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db, isFirebaseConfigured } from '@/lib/firebase';
import { detectDevice, shouldShowMask, shouldShowBetting, type DeviceInfo } from '@/lib/cloaking';
import type { SiteConfig } from '@/lib/types';
import MaskSite from '@/components/MaskSite';
import BettingSite from '@/components/BettingSite';

// Demo site configuration for when Firebase is not configured
const demoSiteConfig: SiteConfig = {
    id: 'demo',
    name: 'Demo Site',
    domain: 'localhost',
    maskType: 'corporate',
    maskContent: {
        siteName: 'Flovaz Commercial Insurance',
        heroTitle: 'Güvenilir Sigorta Çözümleri',
        heroSubtitle: 'İşletmeniz için en uygun sigorta paketlerini sunuyoruz. 10 yılı aşkın deneyimimizle yanınızdayız.',
        features: [
            {
                id: '1',
                icon: 'shield',
                title: 'Güvenilir Hizmet',
                description: 'Sektörde 10 yılı aşkın deneyim ile müşterilerimize en iyi hizmeti sunuyoruz.',
            },
            {
                id: '2',
                icon: 'award',
                title: 'Ödüllü Ekip',
                description: 'Uzman kadromuz ile her zaman yanınızdayız.',
            },
            {
                id: '3',
                icon: 'users',
                title: 'Müşteri Memnuniyeti',
                description: '%99 müşteri memnuniyeti oranı ile sektörde lideriz.',
            },
            {
                id: '4',
                icon: 'trending-up',
                title: 'Sürekli Gelişim',
                description: 'En yeni teknolojiler ile sürekli kendimizi geliştiriyoruz.',
            },
        ],
        services: [
            {
                id: '1',
                name: 'Temel Sigorta Paketi',
                description: 'Küçük işletmeler için ideal sigorta çözümü',
                price: '₺999/ay',
            },
            {
                id: '2',
                name: 'Profesyonel Paket',
                description: 'Orta ölçekli şirketler için kapsamlı koruma',
                price: '₺2.499/ay',
            },
            {
                id: '3',
                name: 'Kurumsal Paket',
                description: 'Büyük organizasyonlar için tam koruma',
                price: '₺4.999/ay',
            },
        ],
        testimonials: [
            {
                id: '1',
                name: 'Ahmet Yılmaz',
                role: 'CEO, ABC Şirketi',
                content: 'Harika bir hizmet aldık, kesinlikle tavsiye ederim!',
                rating: 5,
            },
            {
                id: '2',
                name: 'Ayşe Demir',
                role: 'Müdür, XYZ Ltd.',
                content: 'Profesyonel ekip ve kaliteli hizmet.',
                rating: 5,
            },
            {
                id: '3',
                name: 'Mehmet Kaya',
                role: 'İşletme Sahibi',
                content: 'Güvenilir ve hızlı çözümler sunuyorlar.',
                rating: 5,
            },
        ],
        contactInfo: {
            email: 'info@flovaz.com',
            phone: '+90 555 123 4567',
            address: 'İstanbul, Türkiye',
            socialMedia: {
                facebook: 'https://facebook.com',
                twitter: 'https://twitter.com',
                instagram: 'https://instagram.com',
            },
        },
        colorScheme: {
            primary: '#3B82F6',
            secondary: '#8B5CF6',
            accent: '#EC4899',
            background: '#FFFFFF',
            text: '#1F2937',
        },
    },
    bettingContent: {
        bonuses: [
            {
                id: '1',
                title: '1000 TL Hoş Geldin Bonusu',
                description: 'İlk üyeliğinize özel %100 bonus fırsatı',
                amount: '1000 TL',
                badge: 'YENİ',
                link: 'https://example.com',
                order: 1,
                isActive: true,
            },
            {
                id: '2',
                title: '500 TL Deneme Bonusu',
                description: 'Kayıt olun, bedava bonus kazanın',
                amount: '500 TL',
                badge: 'POPÜLER',
                link: 'https://example.com',
                order: 2,
                isActive: true,
            },
            {
                id: '3',
                title: '2000 TL Casino Bonusu',
                description: 'Casino oyunları için özel bonus',
                amount: '2000 TL',
                badge: 'ÖZEL',
                link: 'https://example.com',
                order: 3,
                isActive: true,
            },
        ],
        liveWinners: [
            {
                id: '1',
                username: 'Mehmet***',
                amount: '5.000 TL',
                game: 'Sweet Bonanza',
                timestamp: new Date(),
            },
            {
                id: '2',
                username: 'Ayşe***',
                amount: '3.500 TL',
                game: 'Gates of Olympus',
                timestamp: new Date(),
            },
            {
                id: '3',
                username: 'Ali***',
                amount: '7.200 TL',
                game: 'Book of Ra',
                timestamp: new Date(),
            },
        ],
        popups: [
            {
                id: '1',
                title: 'Hoş Geldiniz!',
                content: 'İlk üyeliğinize özel %100 bonus fırsatını kaçırmayın!',
                ctaText: 'Hemen Üye Ol',
                ctaLink: 'https://example.com',
                showDelay: 3000,
                isActive: true,
            },
        ],
        heroSlides: [
            {
                id: '1',
                title: 'En Yüksek Bonuslar',
                subtitle: 'Türkiye\'nin en çok bonus veren sitesi',
                image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200',
                ctaText: 'Hemen Başla',
                ctaLink: 'https://example.com',
                order: 1,
            },
            {
                id: '2',
                title: 'Canlı Casino',
                subtitle: 'Gerçek krupiyelerle casino keyfi',
                image: 'https://images.unsplash.com/photo-1596838132731c3fd4317?w=1200',
                ctaText: 'Oyna',
                ctaLink: 'https://example.com',
                order: 2,
            },
        ],
        quickActions: [
            {
                id: '1',
                icon: 'trophy',
                label: 'Spor',
                link: '#',
                color: 'bg-blue-600',
                order: 1,
            },
            {
                id: '2',
                icon: 'dice',
                label: 'Casino',
                link: '#',
                color: 'bg-purple-600',
                order: 2,
            },
            {
                id: '3',
                icon: 'zap',
                label: 'Canlı',
                link: '#',
                color: 'bg-red-600',
                order: 3,
            },
            {
                id: '4',
                icon: 'gift',
                label: 'Bonuslar',
                link: '#',
                color: 'bg-yellow-600',
                order: 4,
            },
        ],
        announcements: [
            {
                id: '1',
                text: '🎉 Yeni üyelere özel 1000 TL bonus!',
                type: 'success',
                isActive: true,
            },
        ],
    },
    cloakingRules: {
        showMaskTo: {
            desktop: true,
            bots: true,
            excludedCountries: ['US', 'GB', 'DE'],
        },
        showBettingTo: {
            mobile: true,
            includedCountries: ['TR', 'CY'],
        },
        userAgentRules: [],
    },
    seoSettings: {
        metaTitle: 'Flovaz Commercial Insurance - Güvenilir Sigorta Çözümleri',
        metaDescription: 'İşletmeniz için en uygun sigorta paketlerini sunuyoruz. 10 yılı aşkın deneyimimizle yanınızdayız.',
        keywords: ['sigorta', 'ticari sigorta', 'işletme sigortası', 'güvenilir sigorta'],
        hiddenSEOArticle: `
      <h2>Deneme Bonusu Veren Siteler 2026</h2>
      <p>En güncel deneme bonusu veren siteler listesi. Bedava bonus fırsatlarını kaçırmayın!</p>
      <p>2026 yılının en iyi bahis siteleri ve casino bonusları burada. Güvenilir bahis siteleri ile kazanmaya başlayın.</p>
    `,
    },
    createdAt: new Date(),
    updatedAt: new Date(),
    isActive: true,
};

export default function CloakedHome() {
    const [loading, setLoading] = useState(true);
    const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
    const [siteConfig, setSiteConfig] = useState<SiteConfig | null>(null);
    const [showMask, setShowMask] = useState(false);

    useEffect(() => {
        async function init() {
            try {
                // Detect device
                const device = await detectDevice();
                setDeviceInfo(device);

                // If Firebase is not configured, use demo data
                if (!isFirebaseConfigured || !db) {
                    console.log('Firebase not configured, using demo data');
                    setSiteConfig(demoSiteConfig);
                    const shouldMask = shouldShowMask(device, demoSiteConfig.cloakingRules);
                    setShowMask(shouldMask);
                    setLoading(false);
                    return;
                }

                // Get current domain
                const currentDomain = window.location.hostname;

                // Fetch site configuration from Firestore
                const sitesRef = collection(db, 'sites');
                const q = query(sitesRef, where('domain', '==', currentDomain), where('isActive', '==', true));
                const querySnapshot = await getDocs(q);

                if (!querySnapshot.empty) {
                    const siteData = querySnapshot.docs[0].data() as SiteConfig;
                    setSiteConfig(siteData);

                    // Determine what to show
                    const shouldMask = shouldShowMask(device, siteData.cloakingRules);
                    setShowMask(shouldMask);
                } else {
                    // No config found, use demo data
                    console.log('No site config found for domain, using demo data');
                    setSiteConfig(demoSiteConfig);
                    const shouldMask = shouldShowMask(device, demoSiteConfig.cloakingRules);
                    setShowMask(shouldMask);
                }
            } catch (error) {
                console.error('Error initializing cloaking:', error);
                // On error, use demo data
                setSiteConfig(demoSiteConfig);
                setShowMask(true);
            } finally {
                setLoading(false);
            }
        }

        init();
    }, []);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
                <div className="text-center">
                    <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-white text-lg">Yükleniyor...</p>
                </div>
            </div>
        );
    }

    if (!siteConfig) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
                <div className="text-center text-white max-w-2xl px-4">
                    <h1 className="text-4xl font-bold mb-4">🎭 Cloaking Platform</h1>
                    <p className="text-lg mb-6">
                        {!isFirebaseConfigured
                            ? 'Firebase yapılandırması bulunamadı. Lütfen .env.local dosyasını oluşturun ve Firebase bilgilerinizi ekleyin.'
                            : 'Site yapılandırması bulunamadı. Lütfen admin panelinden bir site oluşturun.'
                        }
                    </p>
                    <a
                        href="/admin/login"
                        className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 px-8 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all"
                    >
                        Admin Paneline Git
                    </a>
                </div>
            </div>
        );
    }

    return (
        <>
            {!isFirebaseConfigured && (
                <div className="fixed top-0 left-0 right-0 bg-yellow-500 text-black px-4 py-2 text-center text-sm font-medium z-50">
                    ⚠️ DEMO MODE: Firebase yapılandırılmamış. Gerçek veritabanı bağlantısı için .env.local dosyasını düzenleyin.
                </div>
            )}
            <div className={!isFirebaseConfigured ? 'mt-10' : ''}>
                {showMask ? (
                    <MaskSite config={siteConfig} />
                ) : (
                    <BettingSite config={siteConfig} />
                )}
            </div>
        </>
    );
}
