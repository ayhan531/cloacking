# 🔐 Admin Panel Giriş Bilgileri

## ⚠️ ÖNEMLİ: İlk Kurulum Gerekli

Bu platform şu an **DEMO MODE**'da çalışıyor. Admin paneline giriş yapabilmek için önce Firebase kurulumunu tamamlamanız gerekiyor.

## 🚀 Hızlı Başlangıç

### 1. Firebase Kurulumu (5 Dakika)

#### A) Firebase Projesi Oluştur
1. [Firebase Console](https://console.firebase.google.com/) → "Add Project"
2. Proje adı: `cloaking-platform` (veya istediğin isim)
3. Google Analytics: İsteğe bağlı
4. "Create Project" → Bekle

#### B) Web App Ekle
1. Firebase Console → Proje seç → Web ikonu (</>)
2. App nickname: `Cloaking Web`
3. "Register app" → **Config bilgilerini kopyala**

#### C) Authentication Aktif Et
1. Sol menü → "Authentication" → "Get Started"
2. "Sign-in method" → "Email/Password" → **Enable** → Save

#### D) Firestore Database Oluştur
1. Sol menü → "Firestore Database" → "Create database"
2. "Start in production mode" → Location seç → "Enable"

#### E) Security Rules Ekle
Firestore → "Rules" sekmesi → Aşağıdaki kuralları yapıştır:

\`\`\`javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /sites/{siteId} {
      allow read: if true;
      allow write: if request.auth != null && 
                     exists(/databases/$(database)/documents/admins/$(request.auth.uid));
    }
    
    match /admins/{adminId} {
      allow read: if request.auth != null && request.auth.uid == adminId;
      allow write: if false;
    }
  }
}
\`\`\`

"Publish" butonuna tıkla.

### 2. Environment Variables Ayarla

Proje klasöründe `.env.local` dosyasını düzenle:

\`\`\`env
NEXT_PUBLIC_FIREBASE_API_KEY=AIza... (Firebase'den kopyala)
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc...
\`\`\`

### 3. İlk Admin Kullanıcısı Oluştur

#### A) Authentication'da Kullanıcı Ekle
1. Firebase Console → Authentication → Users → "Add user"
2. Email: `admin@example.com` (veya istediğin email)
3. Password: `Admin123!` (veya güçlü bir şifre)
4. "Add user" → **UID'yi kopyala** (örn: `abc123def456...`)

#### B) Firestore'da Admin Kaydı Oluştur
1. Firestore Database → "Start collection"
2. Collection ID: `admins` → Next
3. Document ID: **Kopyaladığın UID'yi yapıştır**
4. Fields ekle:
   - `email` (string): `admin@example.com`
   - `role` (string): `admin`
   - `createdAt` (timestamp): (şu anki zaman seç)
5. "Save"

### 4. Dev Server'ı Yeniden Başlat

\`\`\`bash
# Terminal'de Ctrl+C ile durdur
# Sonra tekrar başlat:
npm run dev
\`\`\`

### 5. Admin Paneline Giriş Yap

1. Tarayıcıda: `http://localhost:3000/admin/login`
2. Email: `admin@example.com`
3. Password: `Admin123!`
4. "Giriş Yap" → Dashboard'a yönlendirileceksin

---

## 📋 Varsayılan Admin Bilgileri

Firebase kurulumunu tamamladıktan sonra oluşturacağın admin bilgileri:

\`\`\`
Email: admin@example.com (veya senin seçtiğin)
Şifre: Admin123! (veya senin seçtiğin)
\`\`\`

**⚠️ ÖNEMLİ**: Güvenlik için production'da mutlaka güçlü bir şifre kullan!

---

## 🎯 Admin Paneli Özellikleri

Giriş yaptıktan sonra:

### Dashboard (`/admin/dashboard`)
- Toplam site sayısı
- Aktif/Pasif site istatistikleri
- Sistem durumu
- Hızlı başlangıç rehberi

### Siteler (`/admin/sites`)
- **Yeni Site Oluştur**: Sınırsız site oluşturabilirsin
- **Site Düzenle**: Mevcut siteleri düzenle
- **Aktif/Pasif**: Siteleri anında aktif/pasif yap
- **Sil**: İstenmeyen siteleri sil

### Site Oluşturma Formu (4 Sekme)

#### 1. Temel Bilgiler
- Site adı
- Domain
- Görünen site adı

#### 2. Mask İçerik (Botlar ve Desktop için)
- Hero başlık ve alt başlık
- Email, telefon, adres
- Ana renk ve ikincil renk seçimi

#### 3. SEO Ayarları
- Meta başlık
- Meta açıklama
- Anahtar kelimeler
- **Gizli SEO makalesi** (sadece botlar görür)

#### 4. Cloaking Kuralları
- Mask gösterilecek kişiler (Desktop, Botlar, Ülkeler)
- Betting gösterilecek kişiler (Mobil, TR/CY)

---

## 🚨 Sorun Giderme

### "Firebase: Error (auth/invalid-api-key)"
- `.env.local` dosyasının proje kök dizininde olduğundan emin ol
- API key'in doğru kopyalandığından emin ol
- Dev server'ı yeniden başlat

### "Giriş başarısız"
- Email ve şifrenin doğru olduğundan emin ol
- Authentication'da kullanıcının oluşturulduğunu kontrol et

### "Admin paneline erişilemiyor"
- Firestore'da `admins` collection'ında kaydının olduğundan emin ol
- UID'nin doğru olduğunu kontrol et
- Security rules'un doğru ayarlandığından emin ol

### "Site oluşturulamıyor"
- Firestore Security Rules'un doğru olduğundan emin ol
- Admin kullanıcısının `admins` collection'ında olduğunu kontrol et

---

## 📞 Destek

Sorun yaşarsan:
1. `FIREBASE_SETUP.md` dosyasına detaylı bakabilirsin
2. `README.md` dosyasında genel bilgiler var
3. Firebase Console'da hata loglarını kontrol edebilirsin

---

## ✅ Kurulum Tamamlandı mı?

Eğer:
- ✅ Firebase projesi oluşturduysan
- ✅ `.env.local` dosyasını düzenlediysen
- ✅ Admin kullanıcısı oluşturduysan
- ✅ Dev server'ı yeniden başlattıysan

O zaman **hazırsın**! `http://localhost:3000/admin/login` adresinden giriş yapabilirsin.

**İyi çalışmalar! 🚀**
