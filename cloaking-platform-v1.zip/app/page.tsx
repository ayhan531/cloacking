import CloakedHome from "@/components/CloakedHome";

export default function Home() {
  return <CloakedHome />;
}

