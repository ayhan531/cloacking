'use client';

import { useEffect, useState } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Globe, CheckCircle, XCircle, Activity } from 'lucide-react';

export default function AdminDashboard() {
    const [stats, setStats] = useState({
        totalSites: 0,
        activeSites: 0,
        inactiveSites: 0,
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchStats() {
            try {
                const sitesRef = collection(db, 'sites');
                const sitesSnapshot = await getDocs(sitesRef);

                const totalSites = sitesSnapshot.size;
                const activeSites = sitesSnapshot.docs.filter(doc => doc.data().isActive).length;
                const inactiveSites = totalSites - activeSites;

                setStats({
                    totalSites,
                    activeSites,
                    inactiveSites,
                });
            } catch (error) {
                console.error('Error fetching stats:', error);
            } finally {
                setLoading(false);
            }
        }

        fetchStats();
    }, []);

    const statCards = [
        {
            title: 'Toplam Siteler',
            value: stats.totalSites,
            icon: Globe,
            color: 'from-blue-600 to-cyan-600',
        },
        {
            title: 'Aktif Siteler',
            value: stats.activeSites,
            icon: CheckCircle,
            color: 'from-green-600 to-emerald-600',
        },
        {
            title: 'Pasif Siteler',
            value: stats.inactiveSites,
            icon: XCircle,
            color: 'from-red-600 to-pink-600',
        },
        {
            title: 'Sistem Durumu',
            value: 'Çalışıyor',
            icon: Activity,
            color: 'from-purple-600 to-pink-600',
        },
    ];

    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                    Dashboard
                </h1>
                <p className="text-gray-600 text-lg">
                    Cloaking Platform yönetim paneline hoş geldiniz
                </p>
            </div>

            {loading ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[1, 2, 3, 4].map((i) => (
                        <Card key={i} className="border-0 shadow-lg animate-pulse">
                            <CardHeader className="h-32 bg-gray-200 rounded-t-lg"></CardHeader>
                        </Card>
                    ))}
                </div>
            ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {statCards.map((stat) => {
                        const Icon = stat.icon;
                        return (
                            <Card key={stat.title} className="border-0 shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
                                <div className={`h-2 bg-gradient-to-r ${stat.color}`}></div>
                                <CardHeader>
                                    <div className="flex items-center justify-between">
                                        <CardTitle className="text-lg text-gray-600">{stat.title}</CardTitle>
                                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${stat.color} flex items-center justify-center`}>
                                            <Icon className="w-6 h-6 text-white" />
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                                        {stat.value}
                                    </p>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>
            )}

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-0 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-2xl">Hızlı Başlangıç</CardTitle>
                        <CardDescription>Platform özelliklerini keşfedin</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                            <h3 className="font-semibold mb-2">🎯 Yeni Site Oluştur</h3>
                            <p className="text-sm text-gray-600">
                                Siteler bölümünden yeni bir cloaking sitesi oluşturabilirsiniz.
                            </p>
                        </div>
                        <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                            <h3 className="font-semibold mb-2">⚙️ Cloaking Kuralları</h3>
                            <p className="text-sm text-gray-600">
                                Her site için özel cloaking kuralları belirleyebilirsiniz.
                            </p>
                        </div>
                        <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                            <h3 className="font-semibold mb-2">🎨 İçerik Yönetimi</h3>
                            <p className="text-sm text-gray-600">
                                Mask ve betting içeriklerini kolayca düzenleyebilirsiniz.
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-0 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-2xl">Sistem Bilgileri</CardTitle>
                        <CardDescription>Platform durumu ve özellikler</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <span className="text-sm font-medium">Firebase Bağlantısı</span>
                            <span className="text-sm text-green-600 font-semibold">✓ Aktif</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <span className="text-sm font-medium">Cloaking Sistemi</span>
                            <span className="text-sm text-green-600 font-semibold">✓ Çalışıyor</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <span className="text-sm font-medium">Statik Export</span>
                            <span className="text-sm text-green-600 font-semibold">✓ Etkin</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <span className="text-sm font-medium">Platform Versiyonu</span>
                            <span className="text-sm text-gray-600 font-semibold">v1.0.0</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
