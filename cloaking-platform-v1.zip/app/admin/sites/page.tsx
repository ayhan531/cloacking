'use client';

import { useEffect, useState } from 'react';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { SiteConfig } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Edit, Trash2, Globe, Power, PowerOff } from 'lucide-react';

export default function SitesPage() {
    const [sites, setSites] = useState<SiteConfig[]>([]);
    const [loading, setLoading] = useState(true);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [editingSite, setEditingSite] = useState<SiteConfig | null>(null);

    // Form states
    const [formData, setFormData] = useState({
        name: '',
        domain: '',
        maskType: 'corporate' as const,
        // Mask Content
        siteName: '',
        heroTitle: '',
        heroSubtitle: '',
        // SEO
        metaTitle: '',
        metaDescription: '',
        keywords: '',
        hiddenSEOArticle: '',
        // Contact
        email: '',
        phone: '',
        address: '',
        // Cloaking Rules
        showMaskToDesktop: true,
        showMaskToBots: true,
        excludedCountries: 'US,GB,DE',
        includedCountries: 'TR,CY',
        // Colors
        primaryColor: '#3B82F6',
        secondaryColor: '#8B5CF6',
    });

    useEffect(() => {
        fetchSites();
    }, []);

    const fetchSites = async () => {
        try {
            const sitesRef = collection(db, 'sites');
            const sitesSnapshot = await getDocs(sitesRef);
            const sitesData = sitesSnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
                createdAt: doc.data().createdAt?.toDate() || new Date(),
                updatedAt: doc.data().updatedAt?.toDate() || new Date(),
            })) as SiteConfig[];
            setSites(sitesData);
        } catch (error) {
            console.error('Error fetching sites:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateSite = async () => {
        try {
            const newSite: Omit<SiteConfig, 'id'> = {
                name: formData.name,
                domain: formData.domain,
                maskType: formData.maskType,
                maskContent: {
                    siteName: formData.siteName,
                    heroTitle: formData.heroTitle,
                    heroSubtitle: formData.heroSubtitle,
                    features: [
                        {
                            id: '1',
                            icon: 'shield',
                            title: 'Güvenilir Hizmet',
                            description: 'Sektörde 10 yılı aşkın deneyim',
                        },
                        {
                            id: '2',
                            icon: 'award',
                            title: 'Ödüllü Ekip',
                            description: 'Uzman kadromuzla yanınızdayız',
                        },
                        {
                            id: '3',
                            icon: 'users',
                            title: 'Müşteri Memnuniyeti',
                            description: '%99 müşteri memnuniyeti oranı',
                        },
                        {
                            id: '4',
                            icon: 'trending-up',
                            title: 'Sürekli Gelişim',
                            description: 'En yeni teknolojilerle çalışıyoruz',
                        },
                    ],
                    services: [
                        {
                            id: '1',
                            name: 'Temel Paket',
                            description: 'Küçük işletmeler için ideal çözüm',
                            price: '₺999/ay',
                        },
                        {
                            id: '2',
                            name: 'Profesyonel Paket',
                            description: 'Orta ölçekli şirketler için',
                            price: '₺2.499/ay',
                        },
                        {
                            id: '3',
                            name: 'Kurumsal Paket',
                            description: 'Büyük organizasyonlar için',
                            price: '₺4.999/ay',
                        },
                    ],
                    testimonials: [
                        {
                            id: '1',
                            name: 'Ahmet Yılmaz',
                            role: 'CEO, ABC Şirketi',
                            content: 'Harika bir hizmet, kesinlikle tavsiye ederim!',
                            rating: 5,
                        },
                        {
                            id: '2',
                            name: 'Ayşe Demir',
                            role: 'Müdür, XYZ Ltd.',
                            content: 'Profesyonel ekip ve kaliteli hizmet.',
                            rating: 5,
                        },
                    ],
                    contactInfo: {
                        email: formData.email,
                        phone: formData.phone,
                        address: formData.address,
                        socialMedia: {},
                    },
                    colorScheme: {
                        primary: formData.primaryColor,
                        secondary: formData.secondaryColor,
                        accent: '#EC4899',
                        background: '#FFFFFF',
                        text: '#1F2937',
                    },
                },
                bettingContent: {
                    bonuses: [
                        {
                            id: '1',
                            title: '1000 TL Hoş Geldin Bonusu',
                            description: 'İlk üyeliğinize özel %100 bonus',
                            amount: '1000 TL',
                            badge: 'YENİ',
                            link: 'https://example.com',
                            order: 1,
                            isActive: true,
                        },
                        {
                            id: '2',
                            title: '500 TL Deneme Bonusu',
                            description: 'Kayıt olun, bedava bonus kazanın',
                            amount: '500 TL',
                            badge: 'POPÜLER',
                            link: 'https://example.com',
                            order: 2,
                            isActive: true,
                        },
                    ],
                    liveWinners: [
                        {
                            id: '1',
                            username: 'Mehmet***',
                            amount: '5.000 TL',
                            game: 'Sweet Bonanza',
                            timestamp: new Date(),
                        },
                    ],
                    popups: [
                        {
                            id: '1',
                            title: 'Hoş Geldiniz!',
                            content: 'İlk üyeliğinize özel %100 bonus fırsatı',
                            ctaText: 'Hemen Üye Ol',
                            ctaLink: 'https://example.com',
                            showDelay: 3000,
                            isActive: true,
                        },
                    ],
                    heroSlides: [
                        {
                            id: '1',
                            title: 'En Yüksek Bonuslar',
                            subtitle: 'Türkiye\'nin en çok bonus veren sitesi',
                            image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200',
                            ctaText: 'Hemen Başla',
                            ctaLink: 'https://example.com',
                            order: 1,
                        },
                    ],
                    quickActions: [
                        {
                            id: '1',
                            icon: 'trophy',
                            label: 'Spor',
                            link: '#',
                            color: 'bg-blue-600',
                            order: 1,
                        },
                        {
                            id: '2',
                            icon: 'dice',
                            label: 'Casino',
                            link: '#',
                            color: 'bg-purple-600',
                            order: 2,
                        },
                        {
                            id: '3',
                            icon: 'zap',
                            label: 'Canlı',
                            link: '#',
                            color: 'bg-red-600',
                            order: 3,
                        },
                        {
                            id: '4',
                            icon: 'gift',
                            label: 'Bonuslar',
                            link: '#',
                            color: 'bg-yellow-600',
                            order: 4,
                        },
                    ],
                    announcements: [
                        {
                            id: '1',
                            text: '🎉 Yeni üyelere özel 1000 TL bonus!',
                            type: 'success',
                            isActive: true,
                        },
                    ],
                },
                cloakingRules: {
                    showMaskTo: {
                        desktop: formData.showMaskToDesktop,
                        bots: formData.showMaskToBots,
                        excludedCountries: formData.excludedCountries.split(',').map(c => c.trim()),
                    },
                    showBettingTo: {
                        mobile: true,
                        includedCountries: formData.includedCountries.split(',').map(c => c.trim()),
                    },
                    userAgentRules: [],
                },
                seoSettings: {
                    metaTitle: formData.metaTitle,
                    metaDescription: formData.metaDescription,
                    keywords: formData.keywords.split(',').map(k => k.trim()),
                    hiddenSEOArticle: formData.hiddenSEOArticle,
                },
                createdAt: new Date(),
                updatedAt: new Date(),
                isActive: true,
            };

            await addDoc(collection(db, 'sites'), newSite);
            await fetchSites();
            setIsDialogOpen(false);
            resetForm();
        } catch (error) {
            console.error('Error creating site:', error);
            alert('Site oluşturulurken bir hata oluştu.');
        }
    };

    const handleToggleActive = async (siteId: string, currentStatus: boolean) => {
        try {
            const siteRef = doc(db, 'sites', siteId);
            await updateDoc(siteRef, {
                isActive: !currentStatus,
                updatedAt: new Date(),
            });
            await fetchSites();
        } catch (error) {
            console.error('Error toggling site status:', error);
        }
    };

    const handleDeleteSite = async (siteId: string) => {
        if (!confirm('Bu siteyi silmek istediğinizden emin misiniz?')) return;

        try {
            await deleteDoc(doc(db, 'sites', siteId));
            await fetchSites();
        } catch (error) {
            console.error('Error deleting site:', error);
        }
    };

    const resetForm = () => {
        setFormData({
            name: '',
            domain: '',
            maskType: 'corporate',
            siteName: '',
            heroTitle: '',
            heroSubtitle: '',
            metaTitle: '',
            metaDescription: '',
            keywords: '',
            hiddenSEOArticle: '',
            email: '',
            phone: '',
            address: '',
            showMaskToDesktop: true,
            showMaskToBots: true,
            excludedCountries: 'US,GB,DE',
            includedCountries: 'TR,CY',
            primaryColor: '#3B82F6',
            secondaryColor: '#8B5CF6',
        });
        setEditingSite(null);
    };

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                        Siteler
                    </h1>
                    <p className="text-gray-600 text-lg">
                        Cloaking sitelerinizi yönetin ve yeni siteler oluşturun
                    </p>
                </div>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                            <Plus className="w-5 h-5 mr-2" />
                            Yeni Site Oluştur
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle className="text-2xl">Yeni Site Oluştur</DialogTitle>
                            <DialogDescription>
                                Yeni bir cloaking sitesi oluşturun ve içeriklerini düzenleyin
                            </DialogDescription>
                        </DialogHeader>

                        <Tabs defaultValue="basic" className="w-full">
                            <TabsList className="grid w-full grid-cols-4">
                                <TabsTrigger value="basic">Temel</TabsTrigger>
                                <TabsTrigger value="mask">Mask İçerik</TabsTrigger>
                                <TabsTrigger value="seo">SEO</TabsTrigger>
                                <TabsTrigger value="cloaking">Cloaking</TabsTrigger>
                            </TabsList>

                            <TabsContent value="basic" className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="name">Site Adı</Label>
                                        <Input
                                            id="name"
                                            placeholder="Örn: Flovaz Commercial"
                                            value={formData.name}
                                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="domain">Domain</Label>
                                        <Input
                                            id="domain"
                                            placeholder="example.com"
                                            value={formData.domain}
                                            onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="siteName">Görünen Site Adı</Label>
                                    <Input
                                        id="siteName"
                                        placeholder="Web sitesinde görünecek isim"
                                        value={formData.siteName}
                                        onChange={(e) => setFormData({ ...formData, siteName: e.target.value })}
                                    />
                                </div>
                            </TabsContent>

                            <TabsContent value="mask" className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="heroTitle">Hero Başlık</Label>
                                    <Input
                                        id="heroTitle"
                                        placeholder="Ana sayfa başlığı"
                                        value={formData.heroTitle}
                                        onChange={(e) => setFormData({ ...formData, heroTitle: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="heroSubtitle">Hero Alt Başlık</Label>
                                    <Textarea
                                        id="heroSubtitle"
                                        placeholder="Ana sayfa açıklaması"
                                        value={formData.heroSubtitle}
                                        onChange={(e) => setFormData({ ...formData, heroSubtitle: e.target.value })}
                                    />
                                </div>
                                <div className="grid grid-cols-3 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="email">Email</Label>
                                        <Input
                                            id="email"
                                            type="email"
                                            placeholder="info@example.com"
                                            value={formData.email}
                                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="phone">Telefon</Label>
                                        <Input
                                            id="phone"
                                            placeholder="+90 555 123 4567"
                                            value={formData.phone}
                                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="address">Adres</Label>
                                        <Input
                                            id="address"
                                            placeholder="İstanbul, Türkiye"
                                            value={formData.address}
                                            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="primaryColor">Ana Renk</Label>
                                        <Input
                                            id="primaryColor"
                                            type="color"
                                            value={formData.primaryColor}
                                            onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="secondaryColor">İkincil Renk</Label>
                                        <Input
                                            id="secondaryColor"
                                            type="color"
                                            value={formData.secondaryColor}
                                            onChange={(e) => setFormData({ ...formData, secondaryColor: e.target.value })}
                                        />
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="seo" className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="metaTitle">Meta Başlık</Label>
                                    <Input
                                        id="metaTitle"
                                        placeholder="SEO için sayfa başlığı"
                                        value={formData.metaTitle}
                                        onChange={(e) => setFormData({ ...formData, metaTitle: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="metaDescription">Meta Açıklama</Label>
                                    <Textarea
                                        id="metaDescription"
                                        placeholder="SEO için sayfa açıklaması"
                                        value={formData.metaDescription}
                                        onChange={(e) => setFormData({ ...formData, metaDescription: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="keywords">Anahtar Kelimeler (virgülle ayırın)</Label>
                                    <Input
                                        id="keywords"
                                        placeholder="deneme bonusu, bahis, casino"
                                        value={formData.keywords}
                                        onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="hiddenSEOArticle">Gizli SEO Makalesi (Botlar için)</Label>
                                    <Textarea
                                        id="hiddenSEOArticle"
                                        placeholder="Botların göreceği ancak kullanıcıların görmeyeceği SEO içeriği"
                                        rows={6}
                                        value={formData.hiddenSEOArticle}
                                        onChange={(e) => setFormData({ ...formData, hiddenSEOArticle: e.target.value })}
                                    />
                                </div>
                            </TabsContent>

                            <TabsContent value="cloaking" className="space-y-4">
                                <div className="space-y-4">
                                    <div className="p-4 bg-blue-50 rounded-lg">
                                        <h3 className="font-semibold mb-2">Mask Gösterilecek Kişiler</h3>
                                        <div className="space-y-2">
                                            <label className="flex items-center gap-2">
                                                <input
                                                    type="checkbox"
                                                    checked={formData.showMaskToDesktop}
                                                    onChange={(e) => setFormData({ ...formData, showMaskToDesktop: e.target.checked })}
                                                />
                                                <span>Masaüstü kullanıcıları</span>
                                            </label>
                                            <label className="flex items-center gap-2">
                                                <input
                                                    type="checkbox"
                                                    checked={formData.showMaskToBots}
                                                    onChange={(e) => setFormData({ ...formData, showMaskToBots: e.target.checked })}
                                                />
                                                <span>Botlar (Google, Bing, vb.)</span>
                                            </label>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="excludedCountries">Mask Gösterilecek Ülkeler (virgülle ayırın)</Label>
                                        <Input
                                            id="excludedCountries"
                                            placeholder="US,GB,DE"
                                            value={formData.excludedCountries}
                                            onChange={(e) => setFormData({ ...formData, excludedCountries: e.target.value })}
                                        />
                                        <p className="text-sm text-gray-500">Bu ülkelerden gelen kullanıcılara mask gösterilir</p>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="includedCountries">Betting Gösterilecek Ülkeler (virgülle ayırın)</Label>
                                        <Input
                                            id="includedCountries"
                                            placeholder="TR,CY"
                                            value={formData.includedCountries}
                                            onChange={(e) => setFormData({ ...formData, includedCountries: e.target.value })}
                                        />
                                        <p className="text-sm text-gray-500">Bu ülkelerden gelen mobil kullanıcılara betting gösterilir</p>
                                    </div>
                                </div>
                            </TabsContent>
                        </Tabs>

                        <div className="flex justify-end gap-2 mt-6">
                            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                                İptal
                            </Button>
                            <Button
                                className="bg-gradient-to-r from-blue-600 to-purple-600"
                                onClick={handleCreateSite}
                            >
                                Site Oluştur
                            </Button>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>

            {loading ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3].map((i) => (
                        <Card key={i} className="border-0 shadow-lg animate-pulse">
                            <CardHeader className="h-40 bg-gray-200"></CardHeader>
                        </Card>
                    ))}
                </div>
            ) : sites.length === 0 ? (
                <Card className="border-0 shadow-lg">
                    <CardContent className="flex flex-col items-center justify-center py-12">
                        <Globe className="w-16 h-16 text-gray-400 mb-4" />
                        <h3 className="text-xl font-semibold text-gray-600 mb-2">Henüz site oluşturulmamış</h3>
                        <p className="text-gray-500 mb-4">Yeni bir cloaking sitesi oluşturmak için yukarıdaki butona tıklayın</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {sites.map((site) => (
                        <Card key={site.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                            <div className={`h-2 ${site.isActive ? 'bg-gradient-to-r from-green-600 to-emerald-600' : 'bg-gray-400'}`}></div>
                            <CardHeader>
                                <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                        <CardTitle className="text-xl mb-1">{site.name}</CardTitle>
                                        <CardDescription className="flex items-center gap-2">
                                            <Globe className="w-4 h-4" />
                                            {site.domain}
                                        </CardDescription>
                                    </div>
                                    <div className={`px-3 py-1 rounded-full text-xs font-semibold ${site.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                                        }`}>
                                        {site.isActive ? 'Aktif' : 'Pasif'}
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                    <div className="p-2 bg-gray-50 rounded">
                                        <p className="text-gray-500 text-xs">Mask Tipi</p>
                                        <p className="font-medium capitalize">{site.maskType}</p>
                                    </div>
                                    <div className="p-2 bg-gray-50 rounded">
                                        <p className="text-gray-500 text-xs">Oluşturulma</p>
                                        <p className="font-medium">{new Date(site.createdAt).toLocaleDateString('tr-TR')}</p>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        className="flex-1"
                                        onClick={() => handleToggleActive(site.id, site.isActive)}
                                    >
                                        {site.isActive ? (
                                            <>
                                                <PowerOff className="w-4 h-4 mr-1" />
                                                Pasifleştir
                                            </>
                                        ) : (
                                            <>
                                                <Power className="w-4 h-4 mr-1" />
                                                Aktifleştir
                                            </>
                                        )}
                                    </Button>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => handleDeleteSite(site.id)}
                                    >
                                        <Trash2 className="w-4 h-4" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}
