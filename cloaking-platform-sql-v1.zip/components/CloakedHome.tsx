'use client';

import { useEffect, useState } from 'react';
import { detectDevice, shouldShowMask, type DeviceInfo } from '@/lib/cloaking';
import type { SiteConfig } from '@/lib/types';
import MaskSite from '@/components/MaskSite';
import BettingSite from '@/components/BettingSite';

export default function CloakedHome() {
    const [loading, setLoading] = useState(true);
    const [siteConfig, setSiteConfig] = useState<SiteConfig | null>(null);
    const [showMask, setShowMask] = useState(false);

    useEffect(() => {
        async function init() {
            try {
                // Detect device
                const device = await detectDevice();

                // Get current domain
                const currentDomain = window.location.hostname;

                // Fetch site configuration from local SQL API
                const response = await fetch(`/api/sites/by-domain/${currentDomain}`);

                if (response.ok) {
                    const siteData = await response.json();
                    setSiteConfig(siteData);

                    // Determine what to show
                    const shouldMask = shouldShowMask(device, siteData.cloakingRules);
                    setShowMask(shouldMask);
                } else {
                    // No config found, show default loading or error state
                    console.warn('Site configuration not found for domain:', currentDomain);
                }
            } catch (error) {
                console.error('Error initializing cloaking:', error);
            } finally {
                setLoading(false);
            }
        }

        init();
    }, []);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
                <div className="text-center">
                    <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-white text-lg">Yükleniyor...</p>
                </div>
            </div>
        );
    }

    if (!siteConfig) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-4">
                <div className="text-center max-w-md">
                    <h1 className="text-4xl font-bold mb-4">404</h1>
                    <p className="text-gray-400 mb-6">Bu domain için herhangi bir site yapılandırması bulunamadı.</p>
                    <a href="/admin/login" className="bg-purple-600 px-6 py-2 rounded-lg font-medium hover:bg-purple-700 transition">
                        Admin Paneline Git
                    </a>
                </div>
            </div>
        );
    }

    return (
        <>
            {showMask ? (
                <MaskSite config={siteConfig} />
            ) : (
                <BettingSite config={siteConfig} />
            )}
        </>
    );
}
