'use client';

import { useState, useEffect } from 'react';
import type { SiteConfig } from '@/lib/types';
import { Sparkles, Trophy, Zap, Gift, TrendingUp, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface BettingSiteProps {
    config: SiteConfig;
}

export default function BettingSite({ config }: BettingSiteProps) {
    const { bettingContent } = config;
    const [currentSlide, setCurrentSlide] = useState(0);
    const [showPopup, setShowPopup] = useState(false);
    const [currentPopup, setCurrentPopup] = useState(0);

    // Auto-rotate hero slides
    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentSlide((prev) => (prev + 1) % bettingContent.heroSlides.length);
        }, 5000);
        return () => clearInterval(interval);
    }, [bettingContent.heroSlides.length]);

    // Show popup after delay
    useEffect(() => {
        const activePopups = bettingContent.popups.filter(p => p.isActive);
        if (activePopups.length > 0) {
            const timer = setTimeout(() => {
                setShowPopup(true);
            }, activePopups[0].showDelay);
            return () => clearTimeout(timer);
        }
    }, [bettingContent.popups]);

    const activeBonuses = bettingContent.bonuses.filter(b => b.isActive).sort((a, b) => a.order - b.order);
    const activeAnnouncements = bettingContent.announcements.filter(a => a.isActive);
    const sortedQuickActions = [...bettingContent.quickActions].sort((a, b) => a.order - b.order);

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
            {/* Announcements Bar */}
            {activeAnnouncements.length > 0 && (
                <div className={`py-2 px-4 text-center text-sm font-medium ${activeAnnouncements[0].type === 'success' ? 'bg-green-600' :
                        activeAnnouncements[0].type === 'warning' ? 'bg-yellow-600' :
                            'bg-blue-600'
                    } text-white`}>
                    <Sparkles className="inline w-4 h-4 mr-2" />
                    {activeAnnouncements[0].text}
                </div>
            )}

            {/* Hero Slider */}
            <section className="relative h-[400px] overflow-hidden">
                {bettingContent.heroSlides.map((slide, index) => (
                    <div
                        key={slide.id}
                        className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSlide ? 'opacity-100' : 'opacity-0'
                            }`}
                        style={{
                            backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${slide.image})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                        }}
                    >
                        <div className="container mx-auto px-4 h-full flex flex-col justify-center items-center text-center text-white">
                            <h1 className="text-4xl md:text-6xl font-bold mb-4 animate-fade-in">
                                {slide.title}
                            </h1>
                            <p className="text-xl md:text-2xl mb-8 animate-fade-in-delay">
                                {slide.subtitle}
                            </p>
                            <Button
                                size="lg"
                                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg px-8 py-6 animate-pulse"
                            >
                                {slide.ctaText}
                            </Button>
                        </div>
                    </div>
                ))}

                {/* Slide Indicators */}
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                    {bettingContent.heroSlides.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => setCurrentSlide(index)}
                            className={`w-3 h-3 rounded-full transition-all ${index === currentSlide ? 'bg-white w-8' : 'bg-white/50'
                                }`}
                        />
                    ))}
                </div>
            </section>

            {/* Quick Actions */}
            <section className="container mx-auto px-4 py-8">
                <div className="grid grid-cols-4 gap-4">
                    {sortedQuickActions.map((action) => (
                        <a
                            key={action.id}
                            href={action.link}
                            className="flex flex-col items-center gap-2 p-4 rounded-xl bg-white/10 backdrop-blur-md hover:bg-white/20 transition-all hover:scale-105"
                        >
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${action.color}`}>
                                <Trophy className="w-6 h-6 text-white" />
                            </div>
                            <span className="text-white text-sm font-medium text-center">{action.label}</span>
                        </a>
                    ))}
                </div>
            </section>

            {/* Bonuses Section */}
            <section className="container mx-auto px-4 py-8">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-3xl font-bold text-white flex items-center gap-2">
                        <Gift className="w-8 h-8 text-yellow-400" />
                        Günün Fırsatları
                    </h2>
                    <div className="flex items-center gap-2 text-yellow-400 animate-pulse">
                        <Zap className="w-5 h-5" />
                        <span className="text-sm font-bold">CANLI</span>
                    </div>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {activeBonuses.map((bonus) => (
                        <Card key={bonus.id} className="bg-gradient-to-br from-purple-600 to-pink-600 border-0 shadow-2xl hover:shadow-yellow-500/50 transition-all hover:scale-105 overflow-hidden relative">
                            {bonus.badge && (
                                <div className="absolute top-4 right-4 bg-yellow-400 text-black px-3 py-1 rounded-full text-xs font-bold animate-bounce">
                                    {bonus.badge}
                                </div>
                            )}
                            {bonus.image && (
                                <div className="h-32 overflow-hidden">
                                    <img src={bonus.image} alt={bonus.title} className="w-full h-full object-cover opacity-50" />
                                </div>
                            )}
                            <CardHeader>
                                <CardTitle className="text-white text-2xl">{bonus.title}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <p className="text-white/90">{bonus.description}</p>
                                <div className="text-4xl font-bold text-yellow-400">{bonus.amount}</div>
                                <Button
                                    className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-black font-bold"
                                    onClick={() => window.open(bonus.link, '_blank')}
                                >
                                    Hemen Al
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </section>

            {/* Live Winners Ticker */}
            <section className="bg-gradient-to-r from-green-600 to-emerald-600 py-4 overflow-hidden">
                <div className="flex items-center gap-4 animate-scroll">
                    <TrendingUp className="w-6 h-6 text-white flex-shrink-0" />
                    <div className="flex gap-8 whitespace-nowrap">
                        {bettingContent.liveWinners.map((winner) => (
                            <div key={winner.id} className="text-white font-medium">
                                <span className="font-bold">{winner.username}</span> kazandı{' '}
                                <span className="text-yellow-300 font-bold">{winner.amount}</span> -{' '}
                                <span className="text-sm opacity-90">{winner.game}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Popup */}
            {showPopup && bettingContent.popups.filter(p => p.isActive).length > 0 && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                    <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl max-w-md w-full p-6 relative animate-scale-in">
                        <button
                            onClick={() => setShowPopup(false)}
                            className="absolute top-4 right-4 w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
                        >
                            <X className="w-5 h-5 text-white" />
                        </button>

                        {bettingContent.popups.filter(p => p.isActive)[currentPopup].image && (
                            <img
                                src={bettingContent.popups.filter(p => p.isActive)[currentPopup].image}
                                alt="Popup"
                                className="w-full h-48 object-cover rounded-xl mb-4"
                            />
                        )}

                        <h3 className="text-3xl font-bold text-white mb-4">
                            {bettingContent.popups.filter(p => p.isActive)[currentPopup].title}
                        </h3>
                        <p className="text-white/90 mb-6">
                            {bettingContent.popups.filter(p => p.isActive)[currentPopup].content}
                        </p>
                        <Button
                            className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-black font-bold text-lg py-6"
                            onClick={() => {
                                window.open(bettingContent.popups.filter(p => p.isActive)[currentPopup].ctaLink, '_blank');
                                setShowPopup(false);
                            }}
                        >
                            {bettingContent.popups.filter(p => p.isActive)[currentPopup].ctaText}
                        </Button>
                    </div>
                </div>
            )}

            {/* Footer */}
            <footer className="bg-slate-950 text-white py-8 mt-12">
                <div className="container mx-auto px-4 text-center">
                    <p className="text-sm text-gray-400">
                        18+ | Sorumlu Bahis | Kumar bağımlılığı yapabilir
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                        &copy; 2026 Tüm hakları saklıdır.
                    </p>
                </div>
            </footer>

            <style jsx>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes scale-in {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        
        .animate-scroll {
          animation: scroll 20s linear infinite;
        }
        
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
        
        .animate-fade-in-delay {
          animation: fade-in 1s ease-out 0.3s both;
        }
        
        .animate-scale-in {
          animation: scale-in 0.3s ease-out;
        }
      `}</style>
        </div>
    );
}
