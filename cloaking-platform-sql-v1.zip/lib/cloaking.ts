'use client';

export interface DeviceInfo {
    isMobile: boolean;
    isDesktop: boolean;
    isBot: boolean;
    country: string | null;
    userAgent: string;
}

export async function detectDevice(): Promise<DeviceInfo> {
    const userAgent = navigator.userAgent || '';

    // Bot detection
    const botPatterns = [
        /bot/i,
        /crawl/i,
        /spider/i,
        /google/i,
        /bing/i,
        /yahoo/i,
        /baidu/i,
        /yandex/i,
        /facebook/i,
        /twitter/i,
        /whatsapp/i,
        /telegram/i,
    ];

    const isBot = botPatterns.some(pattern => pattern.test(userAgent));

    // Mobile detection
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)
        || window.innerWidth < 768;

    const isDesktop = !isMobile;

    // Country detection
    let country: string | null = null;

    try {
        // Try multiple IP geolocation services
        const response = await fetch('https://ipapi.co/json/', {
            signal: AbortSignal.timeout(3000)
        }).catch(() =>
            fetch('https://ip-api.com/json/', {
                signal: AbortSignal.timeout(3000)
            })
        );

        if (response.ok) {
            const data = await response.json();
            country = data.country_code || data.countryCode || null;
        }
    } catch (error) {
        // Fallback to browser language
        const lang = navigator.language || '';
        if (lang.includes('tr')) country = 'TR';
        else if (lang.includes('cy')) country = 'CY';
    }

    return {
        isMobile,
        isDesktop,
        isBot,
        country,
        userAgent,
    };
}

export function shouldShowMask(deviceInfo: DeviceInfo, rules: any): boolean {
    // Show mask to bots
    if (deviceInfo.isBot && rules.showMaskTo.bots) {
        return true;
    }

    // Show mask to desktop users
    if (deviceInfo.isDesktop && rules.showMaskTo.desktop) {
        return true;
    }

    // Show mask to excluded countries
    if (deviceInfo.country && rules.showMaskTo.excludedCountries.includes(deviceInfo.country)) {
        return true;
    }

    return false;
}

export function shouldShowBetting(deviceInfo: DeviceInfo, rules: any): boolean {
    // Don't show betting to bots
    if (deviceInfo.isBot) {
        return false;
    }

    // Show betting to mobile users from included countries
    if (deviceInfo.isMobile && rules.showBettingTo.mobile) {
        if (!deviceInfo.country) return false;
        return rules.showBettingTo.includedCountries.includes(deviceInfo.country);
    }

    return false;
}
