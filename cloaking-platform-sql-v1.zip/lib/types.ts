// Site Configuration Types
export interface SiteConfig {
    id: string;
    name: string;
    domain: string;
    maskType: 'insurance' | 'corporate' | 'ecommerce' | 'blog' | 'custom';
    maskContent: MaskContent;
    bettingContent: BettingContent;
    cloakingRules: CloakingRules;
    seoSettings: SEOSettings;
    createdAt: Date;
    updatedAt: Date;
    isActive: boolean;
}

export interface MaskContent {
    siteName: string;
    logo?: string;
    heroTitle: string;
    heroSubtitle: string;
    heroImage?: string;
    features: Feature[];
    services: Service[];
    testimonials: Testimonial[];
    contactInfo: ContactInfo;
    customSections?: CustomSection[];
    colorScheme: ColorScheme;
}

export interface Feature {
    id: string;
    icon: string;
    title: string;
    description: string;
}

export interface Service {
    id: string;
    name: string;
    description: string;
    image?: string;
    price?: string;
}

export interface Testimonial {
    id: string;
    name: string;
    role: string;
    content: string;
    avatar?: string;
    rating: number;
}

export interface ContactInfo {
    email: string;
    phone: string;
    address: string;
    socialMedia: {
        facebook?: string;
        twitter?: string;
        instagram?: string;
        linkedin?: string;
    };
}

export interface CustomSection {
    id: string;
    title: string;
    content: string;
    type: 'text' | 'image' | 'video' | 'gallery';
    order: number;
}

export interface ColorScheme {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
}

export interface BettingContent {
    bonuses: Bonus[];
    liveWinners: LiveWinner[];
    popups: Popup[];
    heroSlides: HeroSlide[];
    quickActions: QuickAction[];
    announcements: Announcement[];
}

export interface Bonus {
    id: string;
    title: string;
    description: string;
    amount: string;
    badge?: string;
    link: string;
    image?: string;
    order: number;
    isActive: boolean;
}

export interface LiveWinner {
    id: string;
    username: string;
    amount: string;
    game: string;
    timestamp: Date;
}

export interface Popup {
    id: string;
    title: string;
    content: string;
    image?: string;
    ctaText: string;
    ctaLink: string;
    showDelay: number;
    isActive: boolean;
}

export interface HeroSlide {
    id: string;
    title: string;
    subtitle: string;
    image: string;
    ctaText: string;
    ctaLink: string;
    order: number;
}

export interface QuickAction {
    id: string;
    icon: string;
    label: string;
    link: string;
    color: string;
    order: number;
}

export interface Announcement {
    id: string;
    text: string;
    type: 'info' | 'warning' | 'success';
    isActive: boolean;
}

export interface CloakingRules {
    showMaskTo: {
        desktop: boolean;
        bots: boolean;
        excludedCountries: string[];
    };
    showBettingTo: {
        mobile: boolean;
        includedCountries: string[];
    };
    userAgentRules: string[];
}

export interface SEOSettings {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
    ogImage?: string;
    hiddenSEOArticle?: string;
    structuredData?: any;
}

// Admin User Type
export interface AdminUser {
    uid: string;
    email: string;
    role: 'admin' | 'editor';
    createdAt: Date;
}
