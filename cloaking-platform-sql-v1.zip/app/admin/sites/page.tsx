'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Search, Globe, Shield, Trash2, Power, Edit2, Loader2 } from 'lucide-react';
import type { SiteConfig, MaskContent, BettingContent, CloakingRules, SEOSettings } from '@/lib/types';
import { useAuth } from '@/components/AuthProvider';

const initialMaskContent: MaskContent = {
    siteName: '',
    heroTitle: '',
    heroSubtitle: '',
    features: [],
    services: [],
    testimonials: [],
    contactInfo: {
        email: '',
        phone: '',
        address: '',
        socialMedia: {}
    },
    colorScheme: {
        primary: '#3B82F6',
        secondary: '#8B5CF6',
        accent: '#EC4899',
        background: '#FFFFFF',
        text: '#1F2937'
    }
};

const initialBettingContent: BettingContent = {
    bonuses: [],
    liveWinners: [],
    popups: [],
    heroSlides: [],
    quickActions: [],
    announcements: []
};

const initialCloakingRules: CloakingRules = {
    showMaskTo: {
        desktop: true,
        bots: true,
        excludedCountries: []
    },
    showBettingTo: {
        mobile: true,
        includedCountries: ['TR', 'CY']
    },
    userAgentRules: []
};

const initialSEOSettings: SEOSettings = {
    metaTitle: '',
    metaDescription: '',
    keywords: [],
    hiddenSEOArticle: ''
};

export default function SitesPage() {
    const { isAdmin } = useAuth();
    const [sites, setSites] = useState<SiteConfig[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Form State
    const [newSite, setNewSite] = useState({
        name: '',
        domain: '',
        maskType: 'corporate' as const,
        maskContent: initialMaskContent,
        bettingContent: initialBettingContent,
        cloakingRules: initialCloakingRules,
        seoSettings: initialSEOSettings
    });

    useEffect(() => {
        fetchSites();
    }, []);

    const fetchSites = async () => {
        try {
            const response = await fetch('/api/sites');
            if (response.ok) {
                const data = await response.json();
                setSites(data);
            }
        } catch (error) {
            console.error('Error fetching sites:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateSite = async () => {
        setIsSubmitting(true);
        try {
            const response = await fetch('/api/sites', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newSite),
            });

            if (response.ok) {
                setIsCreateDialogOpen(false);
                fetchSites();
                // Reset form
                setNewSite({
                    name: '',
                    domain: '',
                    maskType: 'corporate',
                    maskContent: initialMaskContent,
                    bettingContent: initialBettingContent,
                    cloakingRules: initialCloakingRules,
                    seoSettings: initialSEOSettings
                });
            }
        } catch (error) {
            console.error('Error creating site:', error);
        } finally {
            setIsSubmitting(false);
        }
    };

    const toggleSiteStatus = async (id: string, currentStatus: boolean) => {
        try {
            const response = await fetch(`/api/sites/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ isActive: !currentStatus }),
            });

            if (response.ok) {
                fetchSites();
            }
        } catch (error) {
            console.error('Error toggling site status:', error);
        }
    };

    const handleDeleteSite = async (id: string) => {
        if (!confirm('Bu siteyi silmek istediğinize emin misiniz?')) return;

        try {
            const response = await fetch(`/api/sites/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                fetchSites();
            }
        } catch (error) {
            console.error('Error deleting site:', error);
        }
    };

    const filteredSites = sites.filter(site =>
        site.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        site.domain.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                        Site Yönetimi
                    </h1>
                    <p className="text-gray-600 text-lg">Tüm cloaking sitelerinizi buradan yönetin.</p>
                </div>

                <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                            <Plus className="w-4 h-4 mr-2" />
                            Yeni Site Oluştur
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle>Yeni Site Oluştur</DialogTitle>
                            <DialogDescription>
                                Yeni bir cloaking sitesi oluşturun. Tüm içerikler SQL veritabanına kaydedilir.
                            </DialogDescription>
                        </DialogHeader>

                        <Tabs defaultValue="basic" className="mt-4">
                            <TabsList className="grid grid-cols-4 w-full">
                                <TabsTrigger value="basic">Temel</TabsTrigger>
                                <TabsTrigger value="mask">Mask İçerik</TabsTrigger>
                                <TabsTrigger value="seo">SEO</TabsTrigger>
                                <TabsTrigger value="cloaking">Cloaking</TabsTrigger>
                            </TabsList>

                            <TabsContent value="basic" className="space-y-4 pt-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Site Adı</Label>
                                        <Input
                                            placeholder="Örn: Sigorta Projesi"
                                            value={newSite.name}
                                            onChange={(e) => setNewSite({ ...newSite, name: e.target.value })}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Domain</Label>
                                        <Input
                                            placeholder="Örn: sigorta-projesi.com"
                                            value={newSite.domain}
                                            onChange={(e) => setNewSite({ ...newSite, domain: e.target.value })}
                                        />
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="mask" className="space-y-4 pt-4">
                                <div className="space-y-2">
                                    <Label>Görünen Site Adı</Label>
                                    <Input
                                        placeholder="Örn: Flovaz Commercial Insurance"
                                        value={newSite.maskContent.siteName}
                                        onChange={(e) => setNewSite({
                                            ...newSite,
                                            maskContent: { ...newSite.maskContent, siteName: e.target.value }
                                        })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Hero Başlık</Label>
                                        <Input
                                            placeholder="Örn: Güvenilir Sigorta Çözümleri"
                                            value={newSite.maskContent.heroTitle}
                                            onChange={(e) => setNewSite({
                                                ...newSite,
                                                maskContent: { ...newSite.maskContent, heroTitle: e.target.value }
                                            })}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Hero Alt Başlık</Label>
                                        <Input
                                            placeholder="Örn: İşletmeniz için en uygun paketler"
                                            value={newSite.maskContent.heroSubtitle}
                                            onChange={(e) => setNewSite({
                                                ...newSite,
                                                maskContent: { ...newSite.maskContent, heroSubtitle: e.target.value }
                                            })}
                                        />
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="seo" className="space-y-4 pt-4">
                                <div className="space-y-2">
                                    <Label>Meta Başlık</Label>
                                    <Input
                                        placeholder="SEO başlığı"
                                        value={newSite.seoSettings.metaTitle}
                                        onChange={(e) => setNewSite({
                                            ...newSite,
                                            seoSettings: { ...newSite.seoSettings, metaTitle: e.target.value }
                                        })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Meta Açıklama</Label>
                                    <Textarea
                                        placeholder="SEO açıklaması"
                                        value={newSite.seoSettings.metaDescription}
                                        onChange={(e) => setNewSite({
                                            ...newSite,
                                            seoSettings: { ...newSite.seoSettings, metaDescription: e.target.value }
                                        })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Gizli SEO Makalesi (Botlar İçin)</Label>
                                    <Textarea
                                        placeholder="HTML formatında SEO makalesi..."
                                        rows={6}
                                        value={newSite.seoSettings.hiddenSEOArticle}
                                        onChange={(e) => setNewSite({
                                            ...newSite,
                                            seoSettings: { ...newSite.seoSettings, hiddenSEOArticle: e.target.value }
                                        })}
                                    />
                                </div>
                            </TabsContent>

                            <TabsContent value="cloaking" className="space-y-4 pt-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="text-sm">Mask Gösterilecekler</CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-2">
                                            <div className="flex items-center gap-2">
                                                <input type="checkbox" checked={newSite.cloakingRules.showMaskTo.desktop} readOnly />
                                                <Label>Masaüstü Kullanıcıları</Label>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <input type="checkbox" checked={newSite.cloakingRules.showMaskTo.bots} readOnly />
                                                <Label>Botlar (Google, Bing vb.)</Label>
                                            </div>
                                        </CardContent>
                                    </Card>
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="text-sm">Betting Gösterilecekler</CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-2">
                                            <div className="flex items-center gap-2">
                                                <input type="checkbox" checked={newSite.cloakingRules.showBettingTo.mobile} readOnly />
                                                <Label>Mobil Kullanıcılar</Label>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </div>
                            </TabsContent>
                        </Tabs>

                        <DialogFooter className="mt-6">
                            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>İptal</Button>
                            <Button
                                onClick={handleCreateSite}
                                className="bg-purple-600"
                                disabled={isSubmitting}
                            >
                                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                Site Oluştur
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            {/* Search and Filters */}
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                    placeholder="Site adı veya domain ara..."
                    className="pl-10 h-12 bg-white/50 backdrop-blur-sm border-0 shadow-lg"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>

            {/* Sites Inventory */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {loading ? (
                    Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="h-64 bg-gray-100 animate-pulse rounded-2xl" />
                    ))
                ) : filteredSites.length > 0 ? (
                    filteredSites.map((site) => (
                        <Card key={site.id} className="border-0 shadow-xl overflow-hidden group hover:translate-y-[-4px] transition-all duration-300">
                            <div className={`h-2 w-full ${site.isActive ? 'bg-emerald-500' : 'bg-gray-300'}`} />
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <div className="p-2 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg group-hover:scale-110 transition-transform">
                                        <Globe className="w-5 h-5 text-purple-600" />
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Button
                                            variant="ghost" size="icon"
                                            onClick={() => toggleSiteStatus(site.id!, site.isActive)}
                                            className={site.isActive ? 'text-emerald-600 hover:text-emerald-700' : 'text-gray-400 hover:text-gray-500'}
                                        >
                                            <Power className="w-5 h-5" />
                                        </Button>
                                        <Button
                                            variant="ghost" size="icon" className="text-blue-600 hover:text-blue-700"
                                        >
                                            <Edit2 className="w-5 h-5" />
                                        </Button>
                                        <Button
                                            variant="ghost" size="icon" className="text-rose-600 hover:text-rose-700"
                                            onClick={() => handleDeleteSite(site.id!)}
                                        >
                                            <Trash2 className="w-5 h-5" />
                                        </Button>
                                    </div>
                                </div>
                                <CardTitle className="text-xl mt-4 font-bold">{site.name}</CardTitle>
                                <CardDescription className="flex items-center gap-2 font-mono text-xs">
                                    <Globe className="w-3 h-3" />
                                    {site.domain}
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                                    <div className="space-y-1">
                                        <p className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Durum</p>
                                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${site.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'}`}>
                                            {site.isActive ? 'Aktif' : 'Pasif'}
                                        </span>
                                    </div>
                                    <div className="space-y-1">
                                        <p className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Mask Tipi</p>
                                        <span className="text-xs font-medium text-gray-700 capitalize">{site.maskType}</span>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))
                ) : (
                    <div className="col-span-full py-12 text-center bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                        <Shield className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-600">Site bulunamadı</h3>
                        <p className="text-gray-400">Yeni bir site oluşturarak başlayın.</p>
                    </div>
                )}
            </div>
        </div>
    );
}
